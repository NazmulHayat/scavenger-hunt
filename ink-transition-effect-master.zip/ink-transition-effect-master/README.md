Ink Transition Effect
=========
An ink bleed transition effect, powered by CSS animations.

[Article on CodyHouse](https://codyhouse.co/gem/ink-transition-effect/)

[Demo](https://codyhouse.co/demo/ink-transition-effect/index.html)
 
[Terms](https://codyhouse.co/terms/)
